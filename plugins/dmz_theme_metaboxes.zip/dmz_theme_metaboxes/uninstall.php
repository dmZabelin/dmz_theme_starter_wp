<?php

if( !defined('WP_UNINSTALL_PLUGIN') ) {
	exit;
}


// remove plugin options
global $wpdb;

$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE 'dmz_%';" );