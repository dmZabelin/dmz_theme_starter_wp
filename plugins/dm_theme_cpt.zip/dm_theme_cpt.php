<?php
/**
 * Plugin Name:CPT dmTheme
 */

/**
 * Add Needed Post Types
 */

	function dm_init_post_types() {
		if (function_exists('dm_get_post_types')) {
			foreach (dm_get_post_types() as $type => $options) {
				dm_add_post_type($type, $options['config'], $options['singular'], $options['multiple']);
			}
		}
	}
	add_action('init', 'dm_init_post_types');

/**
 * Add Needed Taxonomies
 */

	function dm_init_taxonomies() {
		if (function_exists('dm_get_taxonomies')) {
			foreach (dm_get_taxonomies() as $type => $options) {
				dm_add_taxonomy($type, $options['for'], $options['config'], $options['singular'], $options['multiple']);
			}
		}
	}
	add_action('init', 'dm_init_taxonomies');

/**
 * Register Post Type Wrapper
 * @param string $name
 * @param array $config
 * @param string $singular
 * @param string $multiple
 */

	function dm_add_post_type($name, $config, $singular = 'Entry', $multiple = 'Entries') {
		if (!isset($config['labels'])) {
			$config['labels'] = array(
				'name' => $multiple,
				'singular_name' => $singular,
				'not_found'=> 'No ' . $multiple . ' Found',
				'not_found_in_trash'=> 'No ' . $multiple . ' found in Trash',
				'edit_item' => 'Edit ', $singular,
				'search_items' => 'Search ' . $multiple,
				'view_item' => 'View ', $singular,
				'new_item' => 'New ' . $singular,
				'add_new' => 'Add New',
				'add_new_item' => 'Add New ' . $singular,
			);
		}

		register_post_type($name, $config);
	}

/**
* Register taxonomy wrapper
* @param string $name
* @param mixed $object_type
* @param array $config
* @param string $singular
* @param string $multiple
*/

	function dm_add_taxonomy($name, $object_type, $config, $singular = 'Entry', $multiple = 'Entries') {

		if (!isset($config['labels'])) {
			$config['labels'] = array(
				'name' => $multiple,
				'singular_name' => $singular,
				'search_items' =>  'Search ' . $multiple,
				'all_items' => 'All ' . $multiple,
				'parent_item' => 'Parent ' . $singular,
				'parent_item_colon' => 'Parent ' . $singular . ':',
				'edit_item' => 'Edit ' . $singular,
				'update_item' => 'Update ' . $singular,
				'add_new_item' => 'Add New ' . $singular,
				'new_item_name' => 'New ' . $singular . ' Name',
				'menu_name' => $singular,
			);
		}

		register_taxonomy($name, $object_type, $config);
	}

/**
 * Add post types that are used in the theme
 *
 * @return array
 */

	function dm_get_post_types() {
		return array(
			'projects' => array(
				'config' => array(
						'public' => true,
						'menu_position' => 20,
						'has_archive'   => true,
						'menu_icon'     => 'dashicons-thumbs-up',
						'supports'=> array(
							'title',
							'editor',
							'comments',
							'thumbnail',
						),
						'show_in_nav_menus'=> true,
				),
				'singular' => 'Project',
				'multiple' => 'Pojects'
			),			
			'reviews' => array(
				'config' => array(
						'public' => true,
						'menu_position' => 20,
						'has_archive'   => true,
						'menu_icon'     => 'dashicons-thumbs-up',
						'supports'=> array(
							'title',
							'editor',
							'comments',
							'thumbnail',
						),
						'show_in_nav_menus'=> true,
				),
				'singular' => 'Review',
				'multiple' => 'Reviews'
			),
		);
	}



/**
* Add taxonomies that are used in theme
*
* @return array
*/
function dm_get_taxonomies() {
	return array(
		 'projects-category'    => array(
			  'for'        => array('projects'),
			  'config'    => array(
					'sort'        => true,
					'args'        => array('orderby' => 'term_order'),
					'hierarchical' => true,
			  ),
			  'singular'    => 'Category',
			  'multiple'    => 'Categories'
		 ),
		 'projects-tag'    => array(
			'for'        => array('projects'),
			'config'    => array(
				 'sort'        => true,
				 'args'        => array('orderby' => 'term_order'),
				 'hierarchical' => false,
			),
			'singular'    => 'Tag',
			'multiple'    => 'Tags'
	  ),
	);
}