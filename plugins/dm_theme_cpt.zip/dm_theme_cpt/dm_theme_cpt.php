<?php
/**
 * Plugin Name:CPT dmTheme
 */

/**
 * Add Needed Post Types
 */

	function dm_init_post_types() {
		if (function_exists('dm_get_post_types')) {
			foreach (dm_get_post_types() as $type => $options) {
				dm_add_post_type($type, $options['config'], $options['singular'], $options['multiple']);
			}
		}
	}
	add_action('init', 'dm_init_post_types');

/**
 * Add Needed Taxonomies
 */

	function dm_init_taxonomies() {
		if (function_exists('dm_get_taxonomies')) {
			foreach (dm_get_taxonomies() as $type => $options) {
				dm_add_taxonomy($type, $options['for'], $options['config'], $options['singular'], $options['multiple']);
			}
		}
	}
	add_action('init', 'dm_init_taxonomies');

/**
 * Register Post Type Wrapper
 * @param string $name
 * @param array $config
 * @param string $singular
 * @param string $multiple
 */

	function dm_add_post_type($name, $config, $singular = 'Entry', $multiple = 'Entries') {
		if (!isset($config['labels'])) {
			$config['labels'] = [
				'name' => $multiple,
				'singular_name' => $singular,
				'not_found'=> esc_html__('No ', 'dmz_theme') . $multiple . esc_html__(' Found', 'dmz_theme'),
				'not_found_in_trash'=> esc_html__('No ', 'dmz_theme') . $multiple . esc_html__(' found in Trash', 'dmz_theme'),
				'edit_item' => esc_html__('Edit ', 'dmz_theme'), $singular,
				'search_items' => esc_html__('Search ', 'dmz_theme') . $multiple,
				'view_item' => esc_html__('View ', 'dmz_theme'), $singular,
				'new_item' => esc_html__('New ', 'dmz_theme') . $singular,
				'add_new' => esc_html__('Add New', 'dmz_theme'),
				'add_new_item' => esc_html__('Add New ', 'dmz_theme') . $singular,
			];
		}

		register_post_type($name, $config);
	}

/**
* Register taxonomy wrapper
* @param string $name
* @param mixed $object_type
* @param array $config
* @param string $singular
* @param string $multiple
*/

	function dm_add_taxonomy($name, $object_type, $config, $singular = 'Entry', $multiple = 'Entries') {

		if (!isset($config['labels'])) {
			$config['labels'] = [
				'name' => $multiple,
				'singular_name' => $singular,
				'search_items' =>  esc_html__('Search ', 'dmz_theme') . $multiple,
				'all_items' => esc_html__('All ', 'dmz_theme') . $multiple,
				'parent_item' => esc_html__('Parent ', 'dmz_theme') . $singular,
				'parent_item_colon' => esc_html__('Parent ', 'dmz_theme') . $singular . ':',
				'edit_item' => esc_html__('Edit ', 'dmz_theme') . $singular,
				'update_item' => esc_html__('Update ', 'dmz_theme') . $singular,
				'add_new_item' => esc_html__('Add New ', 'dmz_theme') . $singular,
				'new_item_name' => esc_html__('New ', 'dmz_theme') . $singular . esc_html__(' Name', 'dmz_theme'),
				'menu_name' => $singular,
			];
		}

		register_taxonomy($name, $object_type, $config);
	}

/**
 * Add post types that are used in the theme
 *
 * @return array
 */

	function dm_get_post_types() {
		return [
			'tests' => [
				'config' => [
						'public' => true,
						'menu_position' => 20,
						'has_archive'   => true,
						'menu_icon'     => 'dashicons-thumbs-up',
						'supports'=> [
							'title',
							'editor',
							'comments',
							'thumbnail',
						],
						'show_in_nav_menus'=> true,
					],
				'singular' => esc_html__('Test', 'dmz_theme'),
				'multiple' => esc_html__('Tests', 'dmz_theme')
			]
		];
	}

/**
* Add taxonomies that are used in theme
*
* @return array
*/

	function dm_get_taxonomies() {
		return [
			'tests-category'    => [
				'for'        => ['tests'],
				'config'    => [
					'sort'        => true,
					'args'        => ['orderby' => 'term_order'],
					'hierarchical' => true,
				],
				'singular'    => esc_html__('Category', 'dmz_theme'),
				'multiple'    => esc_html__('Categories', 'dmz_theme')
			],
			'tests-tag'    => [
				'for'        => ['tests'],
				'config'    => [
					'sort'        => true,
					'args'        => ['orderby' => 'term_order'],
					'hierarchical' => false,
				],
				'singular'    => esc_html__('Tag', 'dmz_theme'),
				'multiple'    => esc_html__('Tags', 'dmz_theme')
			]
		];
	}